﻿Public Class LoginFM
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        BColour(0, 99, 177)

        Panel1.Width = 643
        useridTb.BackColor = Me.BackColor
        Panel3.BackColor = Me.BackColor

        userPassTb.BackColor = Me.BackColor
        Panel4.BackColor = Me.BackColor

    End Sub

    Private Sub TextBox1_Enter(sender As Object, e As EventArgs) Handles useridTb.Enter
        useridTb.BackColor = Color.White
        Panel3.BackColor = Color.White

        userPassTb.BackColor = Me.BackColor
        Panel4.BackColor = Me.BackColor
    End Sub
    Private Sub TextBox1_Leave(sender As Object, e As EventArgs) Handles useridTb.Leave
        useridTb.BackColor = Me.BackColor
        Panel3.BackColor = Me.BackColor
    End Sub


    Private Sub TextBox2_Enter(sender As Object, e As EventArgs) Handles userPassTb.Enter
        useridTb.BackColor = Me.BackColor
        Panel3.BackColor = Me.BackColor

        userPassTb.BackColor = Color.White
        Panel4.BackColor = Color.White
    End Sub
    Private Sub TextBox2_Leave(sender As Object, e As EventArgs) Handles userPassTb.Leave
        userPassTb.BackColor = Me.BackColor
        Panel4.BackColor = Me.BackColor
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        Timer3.Start()
        titleLb1.Text = "Goodbye from"
    End Sub



    Dim x% = 1
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        x = x + 5


        Panel5.Width = x
        If x > 372 Then
            Panel5.Width = 1
            x = 0

            Timer1.Stop()

            wait(1000)
            titleLb5.Visible = False
            wait(500)
            titleLb5.Visible = True
            wait(1000)
            titleLb5.Visible = False
            wait(500)
            titleLb5.Visible = True
            wait(1000)
            titleLb5.Visible = False
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles loginBt.Click
        Timer1.Start()
        titleLb5.Visible = True
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Panel1.Width = Panel1.Width - 10

        If Panel1.Width < 267 Then
            Panel1.Width = 266

            titleLb1.TextAlign = ContentAlignment.MiddleRight
            titleLb2.TextAlign = ContentAlignment.MiddleRight
            titleLb3.TextAlign = ContentAlignment.MiddleRight

            Label4.Visible = True
            Label5.Visible = True



            Timer2.Stop()
        End If

    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Panel1.Width = Panel1.Width + 10

        If Panel1.Width > 642 Then
            Panel1.Width = 648

            titleLb1.TextAlign = ContentAlignment.MiddleCenter
            titleLb2.TextAlign = ContentAlignment.MiddleCenter
            titleLb3.TextAlign = ContentAlignment.MiddleCenter

            Label4.Visible = False
            Label5.Visible = False



            Timer3.Stop()
            wait(2000)
            Me.Close()
        End If
    End Sub

    Private Sub wait(ByVal interval As Integer)
        Dim sw As New Stopwatch
        sw.Start()
        Do While sw.ElapsedMilliseconds < interval
            ' Allows UI to remain responsive
            Application.DoEvents()
        Loop
        sw.Stop()
    End Sub


    Private Sub Form1_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        wait(2000)
        Timer2.Start()
    End Sub


    Private Sub BColour(r As Integer, g As Integer, b As Integer)
        Panel1.BackColor = Color.FromArgb(r, g, b)
        PictureBox2.BackColor = Color.FromArgb(r, g, b)
        PictureBox3.BackColor = Color.FromArgb(r, g, b)
        Label6.ForeColor = Color.FromArgb(r, g, b)
        titleLb4.ForeColor = Color.FromArgb(r, g, b)
        titleLb5.ForeColor = Color.FromArgb(r, g, b)
        Panel5.BackColor = Color.FromArgb(r, g, b)
        loginBt.BackColor = Color.FromArgb(r, g, b)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        BColour(0, 99, 177)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        BColour(3, 131, 135)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        BColour(154, 0, 137)
    End Sub
End Class
